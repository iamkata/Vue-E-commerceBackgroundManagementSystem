// 默认情况下这个文件无论开发阶段还是发布阶段都会生效

// 这是项目在发布阶段需要用到的 babel 插件
const prodPlugins = []
if (process.env.NODE_ENV === 'production') {
  // 安装开发依赖  在发布阶段,会移除console.log
  prodPlugins.push('transform-remove-console')
}

module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ],
  plugins: [
    [
      'component',
      {
        libraryName: 'element-plus',
        styleLibraryName: 'theme-chalk'
      }
    ],
    // ...是展开运算符
    ...prodPlugins,
    // 路由懒加载插件
    "@babel/plugin-syntax-dynamic-import"
  ]
}