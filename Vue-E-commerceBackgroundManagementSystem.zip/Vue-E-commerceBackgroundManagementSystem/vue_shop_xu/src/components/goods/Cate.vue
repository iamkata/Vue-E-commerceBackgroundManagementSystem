<template>
  <div>
    <!-- 面包屑导航 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
    <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
    <el-breadcrumb-item>商品管理</el-breadcrumb-item>
    <el-breadcrumb-item>商品分类</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 卡片视图区域 -->
    <el-card>
      <el-row>
        <el-col>
          <el-button type="primary" @click="showAddCateDialog">添加分类</el-button>
        </el-col>
      </el-row>
      <!-- 表格区域 -->
        <el-table :data="catelist" border stripe
        :tree-props="{children: 'children'}"
        row-key="cat_id"
        >
        <el-table-column type="index"></el-table-column>
        <el-table-column label="分类名称" prop="cat_name"></el-table-column>
        <el-table-column label="是否有效">
          <!-- 如果同时给这一行指定了作用域插槽,那么这一行的prop="mg_state"就会被覆盖,所以就可以删了 -->
          <template v-slot="slotProps">
            <!-- slotProps.row就是当前这一行的数据 -->
            <!-- 这里不用父组件对子组件的内容进行加工,所以不用在子组件中写<slot :info='item'>我是默认内容</slot> -->
            <i v-if="slotProps.row.cat_deleted === true" class="el-icon-success" style="color: lightgreen"></i>
            <i v-else class="el-icon-error" style="color: lightgray"></i>
          </template>
        </el-table-column>
        <el-table-column label="排序">
          <template v-slot="slotProps">
            <!-- slotProps.row就是当前这一行的数据 -->
            <!-- 这里不用父组件对子组件的内容进行加工,所以不用在子组件中写<slot :info='item'>我是默认内容</slot> -->
            <el-tag v-if="slotProps.row.cat_level === 0">一级</el-tag>
            <el-tag type="success" v-else-if="slotProps.row.cat_level === 1">二级</el-tag>
            <el-tag type="danger" v-else>三级</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <!-- 如果没有使用v-slot="slotProps",就不用使用template了,直接写就好了 -->
          <template v-slot="slotProps">
            <el-button size="mini" type="primary" icon="el-icon-edit" @click="showEditCateDialog(slotProps.row.cat_id)">编辑</el-button>
            <el-button size="mini" type="danger" icon="el-icon-delete" @click="removeCateById(slotProps.row.cat_id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页区域 -->
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="querInfo.pagenum"
        :page-sizes="[1, 2, 5, 10]"
        :page-size="querInfo.pagesize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
      <!-- 添加分类的对话框 -->
      <el-dialog
        title="添加分类"
        v-model="addCateDialogVisible"
        width="50%"
        @close="addCateDialogClosed">
        <!-- 内容主体区域表单 -->
        <el-form :model="addCateForm" :rules="addCateFormRules" ref="addCateFormRef" label-width="70px">
          <!-- 通过prop="username"指定具体的校验规则 -->
          <el-form-item label="分类名称" prop="cat_name" label-width="100px">
            <el-input v-model="addCateForm.cat_name"></el-input>
          </el-form-item>
          <el-form-item label="父级分类" label-width="100px">
            <!--
              v-model: 双向绑定选中的数值
              options: 指定数据源
              props: 配置选项
              parentCateChange: 选中一个级别时触发
              clearable: 是否可清空
            -->
            <el-cascader
            v-model="selectedKeys"
            :options="parentCateList"
            :props="cascaderProps"
            @change="parentCateChange"
            clearable
            style="width: 100%;"
            >
            </el-cascader>
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="addCateDialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="addCate">确 定</el-button>
          </span>
        </template>
      </el-dialog>
      <!-- 修改分类的对话框 -->
      <el-dialog title="修改分类" v-model="editCateDialogVisible" width="50%" @close="editCateDialogClosed">
        <!-- 内容主体区域表单 -->
        <el-form :model="editCateForm" :rules="editCateFormRules" ref="editCateFormRef" label-width="100px">
          <el-form-item label="分类名称" prop="cat_name">
            <el-input v-model="editCateForm.cat_name"></el-input>
          </el-form-item>
        </el-form>
        <!-- 底部区域 -->
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="editCateDialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="editCateDialogClicked">确 定</el-button>
          </span>
        </template>
      </el-dialog>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 查询条件
      querInfo: {
        type: 3,
        pagenum: 1,
        pagesize: 5
      },
      // 商品分类数据
      catelist: [],
      // 总数据条数
      total: 0,
      // 控制添加分类对话框的显示和隐藏
      addCateDialogVisible: false,
      // 添加分类的表单数据对象
      addCateForm: {
        cat_name: '', // 分类名称
        cat_pid: 0, // 父级分类的id
        cat_level: 0 // 分类等级 0一级分类 1二级分类 2三级分类
      },
      // 添加分类表单的验证规则对象
      addCateFormRules: {
        cat_name: [
          { required: true, message: '请输入分类名称', trigger: 'blur' },
          { min: 3, max: 10, message: '分类名称的长度在3-10个字符之间', trigger: 'blur' }
        ]
      },
      // 父级分类列表
      parentCateList: [],
      // cascader的配置选项
      // checkStrictly: 默认只能选择最后一级,设置为true就可以选择所有级
      // expandTrigger: 设置级联选择器的触发方式 hover悬浮触发
      // value: 'cat_id', 选中的是什么值
      // label: 'cat_name', 显示的是什么值
      // children: 'children' 父子嵌套用什么字段
      cascaderProps: {
        checkStrictly: true,
        expandTrigger: 'hover',
        value: 'cat_id',
        label: 'cat_name',
        children: 'children'
      },
      // 选中的父级分类的id数组
      selectedKeys: [],
      // 修改分类的显示和隐藏
      editCateDialogVisible: false,
      // 修改分类的表单数据对象
      editCateForm: {
        cat_name: '', // 分类名称
        cat_id: '' // 分类名称
      },
      // 修改分类表单的验证规则对象
      editCateFormRules: {
        cat_name: [
          { required: true, message: '请输入分类名称', trigger: 'blur' },
          { min: 3, max: 10, message: '分类名称的长度在3-10个字符之间', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.getCateList()
  },
  methods: {
    async getCateList() {
      const { data: res } = await this.$http.get('categories', {
        params: this.querInfo
      })
      if (res.meta.status !== 200) {
        return this.$message.error('获取分类数据失败')
      }
      // console.log(res.data)
      this.catelist = res.data.result
      this.total = res.data.total
      // console.log(this.catelist)
    },
    // 监听pagesize发生改变
    handleSizeChange(newSize) {
      this.querInfo.pagesize = newSize
      this.getCateList()
    },
    // pagenum发生改变
    handleCurrentChange(newPagenum) {
      this.querInfo.pagenum = newPagenum
      this.getCateList()
    },
    // 点击添加分类按钮
    showAddCateDialog() {
      this.getParentCateList()
      this.addCateDialogVisible = true
    },
    // 获取父级分类的数据
    async getParentCateList() {
      // type为1获取的是一级分类,type为2获取的是一级二级分类,type为3获取的是一级二级三级分类
      const { data: res } = await this.$http('categories', {
        params: { type: 2 }
      })
      if (res.meta.status !== 200) {
        return this.$message.error('获取父级分类数据失败')
      }
      // console.log(res.data)
      this.parentCateList = res.data
    },
    // cascader选择项发生变化
    parentCateChange() {
      // console.log(this.selectedKeys)
      // 如果数值中有值,说明选中了父分类
      if (this.selectedKeys.length > 0) {
        this.addCateForm.cat_pid = this.selectedKeys[this.selectedKeys.length - 1]
        // 数值中有一项,父分类就是一级,数值中有两项,父分类就是二级
        this.addCateForm.cat_level = this.selectedKeys.length
      } else {
        this.addCateForm.cat_pid = 0
        this.addCateForm.cat_level = 0
      }
    },
    // 添加分类点击确认按钮
    addCate() {
      // console.log(this.addCateForm)
      this.$refs.addCateFormRef.validate(async valid => {
        if (!valid) return
        const { data: res } = await this.$http.post('categories', this.addCateForm)
        if (res.meta.status !== 201) {
          return this.$message.error('添加分类失败')
        }
        this.$message.success('添加分类成功')
        this.getCateList()
        this.addCateDialogVisible = false
      })
    },
    // 监听对话框关闭
    addCateDialogClosed() {
      // 重置表单
      this.$refs.addCateFormRef.resetFields()
      // 清空数据
      this.addCateForm.cat_pid = 0
      this.addCateForm.cat_level = 0
      this.selectedKeys = []
    },
    // 点击编辑按钮显示对话框
    async showEditCateDialog(id) {
      // console.log(id)
      const { data: res } = await this.$http.get('categories/' + id)
      if (res.meta.status !== 200) {
        return this.$message.error('查询分类信息失败')
      }
      this.editCateForm = res.data
      // console.log(this.editCateForm)
      this.editCateDialogVisible = true
    },
    // 编辑分类对话框关闭
    editCateDialogClosed() {
      this.$refs.editCateFormRef.resetFields()
    },
    // 编辑分类-点击确定
    editCateDialogClicked() {
      // console.log(this.editCateForm)
      this.$refs.editCateFormRef.validate(async valid => {
        if (valid) {
          const { data: res } = await this.$http.put('categories/' + this.editCateForm.cat_id, {
            cat_name: this.editCateForm.cat_name
          })
          if (res.meta.status !== 200) {
            return this.$message.error('更新分类信息失败')
          }
          this.editCateDialogVisible = false
          this.getCateList()
          this.$message.success('更新分类信息成功')
        }
      })
    },
    // 删除分类
    async removeCateById(id) {
      // console.log(id)
      // 需要挂载ElMessageBox.confirm才可以这样使用
      const confirmResult = await this.$confirm('此操作将永久删除分类, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).catch(err => err)
      // 如果删除成功,则返回字符串confirm,如果取消了,则一定要捕获错误,然后取消之后返回字符串cancel
      // console.log(confirmResult)
      if (confirmResult !== 'confirm') {
        return this.$message.info('已经取消了删除')
      }
      const { data: res } = await this.$http.delete('categories/' + id)
      if (res.meta.status !== 200) {
        return this.$message.error('删除分类失败')
      }
      this.$message.success('删除分类成功')
      this.getCateList()
    }
  }
}
</script>

<style lang="less" scoped>
</style>
