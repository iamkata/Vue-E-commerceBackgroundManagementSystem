<template>
  <div>
    <!-- 面包屑导航 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
    <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
    <el-breadcrumb-item>商品管理</el-breadcrumb-item>
    <el-breadcrumb-item>添加商品</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 卡片视图区域 -->
    <el-card>
      <!-- 提示区域 -->
      <el-alert
        title="添加商品信息"
        type="info"
        center
        show-icon
        :closable="false">
      </el-alert>
      <!-- 步骤条 -->
      <!-- 这里的activeIndex需要的是数值类型的数据,所以我们做一下 - 0 操作 -->
      <el-steps :space="200" :active="activeIndex - 0" finish-status="success" align-center>
        <el-step title="基本信息"></el-step>
        <el-step title="商品参数"></el-step>
        <el-step title="商品属性"></el-step>
        <el-step title="商品图片"></el-step>
        <el-step title="商品内容"></el-step>
        <el-step title="完成"></el-step>
      </el-steps>
      <!-- tab栏区域 -->
      <el-form :model="addForm" :rules="addFormRules" ref="addFormRef" label-width="100px" label-position="top">
        <!-- :tab-position="'left'"左侧标签页 -->
        <!-- 这里的activeIndex需要的是字符串类型的数据 -->
        <el-tabs v-model="activeIndex" :tab-position="'left'" :before-leave="beforeTabLeave" @tab-click="tabClicked">
          <el-tab-pane label="基本信息" name="0">
            <el-form-item label="商品名称" prop="goods_name">
              <el-input v-model="addForm.goods_name"></el-input>
            </el-form-item>
            <el-form-item label="商品价格" prop="goods_price">
              <el-input v-model="addForm.goods_price" type="number"></el-input>
            </el-form-item>
            <el-form-item label="商品重量" prop="goods_weight">
              <el-input v-model="addForm.goods_weight" type="number"></el-input>
            </el-form-item>
            <el-form-item label="商品数量" prop="goods_number">
              <el-input v-model="addForm.goods_number" type="number"></el-input>
            </el-form-item>
            <el-form-item label="商品分类" prop="goods_cat">
              <!-- 选择商品分类的级联选择框 -->
              <!--
                v-model: 双向绑定选中的数值数组 要求必须是数组
                options: 指定数据源
                props: 配置选项
                selectCateChange: 选中一个级别时触发
                clearable: 是否可清空
              -->
              <el-cascader
              v-model="addForm.goods_cat"
              :options="catelist"
              :props="cascaderProps"
              @change="selectCateChange"
              style="width: 300px;"
              >
              </el-cascader>
            </el-form-item>
          </el-tab-pane>
          <el-tab-pane label="商品参数" name="1">
            <el-form-item :label="item.attr_name" v-for="item in manyTableData" :key="item.attr_id">
              <!-- 点击某一个复选框删除一个标签的时候,item.attr_vals数组里面对应的值也会被删除 -->
              <el-checkbox-group v-model="item.attr_vals">
                <el-checkbox :label="item1" v-for="(item1, index) in item.attr_vals" :key="index" border size="small"></el-checkbox>
              </el-checkbox-group>
            </el-form-item>
          </el-tab-pane>
          <el-tab-pane label="商品属性" name="2">
            <el-form-item :label="item.attr_name" v-for="item in onlyTableData" :key="item.attr_id">
              <el-input v-model="item.attr_vals"></el-input>
            </el-form-item>
          </el-tab-pane>
          <el-tab-pane label="商品图片" name="3">
            <!--
            :action="uploadURL" 上传图片地址
            :on-preview="handlePreview" 点击图片名称-预览的事件
            :on-remove="handleRemove" 点击x号的事件
            list-type="picture" 上传图片组件的UI样式,这个是带缩略图的样式
            :on-success="handleSuccess" 图片上传成功的钩子
            -->
            <el-upload
              :action="uploadURL"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              list-type="picture"
              :headers="headerObj"
              :on-success="handleSuccess"
              >
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-tab-pane>
          <el-tab-pane label="商品内容" name="4">
            <!-- 这里使用的是富文本编辑器:vue-quill-editor,在element-ui中,没有类似的组件,我们在可视化界面中添加新的依赖:vue-quill-editor -->
            <!-- 这个富文本编辑器没有适配vue3.x,所以暂时把它注释掉 -->
            <!-- <quill-editor v-model="addForm.goods_introduce"/> -->
            <el-button type="primary" class="btnAdd" @click="add">添加商品</el-button>
          </el-tab-pane>
        </el-tabs>
      </el-form>
    </el-card>
    <!-- 图片预览对话框 -->
    <el-dialog
      title="图片预览"
      v-model="previewVisible"
      width="50%"
      class="previewImg">
      <img src="previewPath" alt="">
    </el-dialog>
  </div>
</template>

<script>
// 导入lodash
import _ from 'lodash'

export default {
  data() {
    return {
      // 默认激活的步骤 字符串
      // 步骤条和tab栏,共用这个数据源
      activeIndex: '0',
      addForm: {
        goods_name: '',
        goods_price: 0,
        goods_weight: 0,
        goods_number: 0,
        // 商品所属的分类数组
        goods_cat: [],
        // 图片的数组
        pics: [],
        // 商品介绍
        goods_introduce: '',
        // 动态参数和静态属性
        attrs: []
      },
      addFormRules: {
        goods_name: [
          { required: true, message: '请输商品名称', trigger: 'blur' },
          { min: 3, max: 10, message: '商品名称的长度在3-10个字符之间', trigger: 'blur' }
        ],
        goods_price: [
          { required: true, message: '请输商品价格', trigger: 'blur' },
          { min: 3, max: 10, message: '商品价格的长度在3-10个字符之间', trigger: 'blur' }
        ],
        goods_weight: [
          { required: true, message: '请输商品重量', trigger: 'blur' },
          { min: 3, max: 10, message: '商品重量的长度在3-10个字符之间', trigger: 'blur' }
        ],
        goods_number: [
          { required: true, message: '请输商品数量', trigger: 'blur' },
          { min: 3, max: 10, message: '商品数量的长度在3-10个字符之间', trigger: 'blur' }
        ],
        goods_cat: [
          { required: true, message: '请选择商品分类', trigger: 'blur' }
        ]
      },
      // 所有分类数组
      catelist: [],
      // cascader的配置选项
      // expandTrigger: 设置级联选择器的触发方式 hover悬浮触发
      // value: 'cat_id', 选中的是什么值
      // label: 'cat_name', 显示的是什么值
      // children: 'children' 父子嵌套用什么字段
      cascaderProps: {
        expandTrigger: 'hover',
        value: 'cat_id',
        label: 'cat_name',
        children: 'children'
      },
      // 动态参数数组
      manyTableData: [],
      // 静态属性数组
      onlyTableData: [],
      // 图片上传地址
      uploadURL: 'http://127.0.0.1:8888/api/private/v1/upload',
      // 图片上传请求头,包含token
      // 虽然设置了token,但是图片上传还是失败,不知道为什么
      headerObj: {
        Authorization: window.sessionStorage.getItem('token')
      },
      // 图片的真实地址,预览图片的时候要访问这个地址
      previewPath: '',
      // 控制图片预览窗口的显示和隐藏
      previewVisible: false
    }
  },
  created() {
    this.getCateList()
  },
  methods: {
    // 获取所有分类数据
    async getCateList() {
      const { data: res } = await this.$http.get('categories')
      if (res.meta.status !== 200) {
        return this.message.error('获取商品分类数据失败')
      }
      this.catelist = res.data
      // console.log(this.catelist)
    },
    // 选中一个级联的时候触发
    selectCateChange() {
      // console.log(this.addForm.goods_cat)
      // 控制只能选择第三级
      if (this.addForm.goods_cat.length !== 3) {
        this.addForm.goods_cat = []
      }
    },
    // tab切换之前触发
    beforeTabLeave(activeName, oldActiveName) {
      // console.log('即将离开的标签页是:' + oldActiveName)
      // console.log('即将进入的标签页是:' + activeName)
      if (oldActiveName === '0' && this.addForm.goods_cat.length !== 3) {
        this.$message.error('请先选择商品分类')
        // 不允许切换
        return false
      }
    },
    // 点击页签的时候触发
    async tabClicked() {
      // console.log(this.activeIndex)
      // 商品参数面板
      if (this.activeIndex === '1') {
        const { data: res } = await this.$http.get(`categories/${this.cateId}/attributes/`, {
          params: { sel: 'many' }
        })
        if (res.meta.status !== 200) {
          return this.$message.error('动态参数获取失败')
        }
        // console.log(res.data)
        // 将tag标签转换成数组
        res.data.forEach(item => {
          // 服务器返回的attr_vals是字符串:"黄春雨10片-补水滋润,黑春雨10片-轻透补水,白春雨10片-焕白保湿"
          // 不为空就分割,为空就直接返回空数组  将字符串使用,分割放到数组中
          item.attr_vals = item.attr_vals.length !== 0 ? item.attr_vals.split(',') : []
        })
        this.manyTableData = res.data
      } else if (this.activeIndex === '2') {
        // 商品属性面板
        const { data: res } = await this.$http.get(`categories/${this.cateId}/attributes/`, {
          params: { sel: 'only' }
        })
        if (res.meta.status !== 200) {
          return this.$message.error('静态属性获取失败')
        }
        // console.log(res.data)
        this.onlyTableData = res.data
      }
    },
    // 点击图片名称-要查看预览效果的那个事件
    handlePreview(file) {
      // console.log(file)
      this.previewPath = file.response.data.url
      this.previewVisible = true
    },
    // 点击x号,移出图片的时候调用
    handleRemove(file) {
      // console.log(file)
      // 1. 获取将要删除的图片的临时路径
      const filePath = file.response.data.tmp_path
      // 2. 从pics数组中,找到这个图片对应的索引值
      const i = this.addForm.pics.findIndex(x => x.pic === filePath)
      // 3. 调用数组的splice方法,把图片信息对象从pics数组中移除
      this.addForm.pics.splice(i, 1)
      console.log(this.addForm)
    },
    // 图片上传成功的钩子
    handleSuccess(response) {
      // console.log(response)
      // 1. 拼接得到一个图片信息对象
      const picInfo = { pic: response.data.tmp_path }
      // 2. 将图片信息对象push到pics数组中
      this.addForm.pics.push(picInfo)
      // console.log(this.addForm)
    },
    // 点击了添加商品按钮
    add() {
      // console.log(this.addForm)
      this.$refs.addFormRef.validate(async valid => {
        if (!valid) {
          return this.$message.error('请填写必要的表单项')
        }
        // 执行添加的业务逻辑
        // 由于级联选择器el-cascader双向绑定了addForm.goods_cat,级联选择器要求绑定的必须是数组,但是我们传给服务器端的时候goods_cat要求是字符串,这时候我们就可以安装依赖:lodash的cloneDeep(obj)进行深拷贝,然后让深拷贝处理之后的对象传给服务端
        const newForm = _.cloneDeep(this.addForm) // 深拷贝
        // 将数组中的元素,使用,拼接成字符串
        newForm.goods_cat = newForm.goods_cat.join(',')
        // 处理动态参数
        this.manyTableData.forEach(item => {
          const newInfo = {
            attr_id: item.attr_id,
            attr_value: item.attr_vals.join(' ')
          }
          this.addForm.attrs.push(newInfo)
        })
        // 处理静态属性
        this.onlyTableData.forEach(item => {
          const newInfo = {
            attr_id: item.attr_id,
            attr_value: item.attr_vals
          }
          this.addForm.attrs.push(newInfo)
        })
        // 给newForm添加attrs
        newForm.attrs = this.addForm.attrs
        console.log(newForm)

        // 发起请求添加商品 商品的名称必须是唯一的
        const { data: res } = await this.$http.post('goods', newForm)
        if (res.meta.status !== 201) {
          console.log(res)
          return this.$message.error('添加商品失败')
        }
        this.$message.success('添加商品成功')
        this.$router.push('/goods')
      })
    }
  },
  // 计算属性
  computed: {
    // 三级分类的id
    cateId() {
      if (this.addForm.goods_cat.length === 3) {
        return this.addForm.goods_cat[2]
      }
      return null
    }
  }
}
</script>

<style lang="less" scoped>
.el-checkbox {
  margin: 0 10px 0 0 !important;
}

.previewImg {
  width: 100%;
}

.btnAdd {
  margin-top: 15px;
}
</style>
