<template>
  <div>
    <!-- 面包屑导航 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
    <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
    <el-breadcrumb-item>商品管理</el-breadcrumb-item>
    <el-breadcrumb-item>参数列表</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 卡片视图区域 -->
    <el-card>
      <!-- 警告区域 -->
      <el-alert
        show-icon
        title="注意: 只允许为三级分类设置相关参数!"
        type="warning"
        :closable="false">
      </el-alert>
      <!-- 选择商品分类区域 -->
      <el-row class="cat_opt">
        <el-col>
          <span>选择商品分类: </span>
            <!-- 选择商品分类的级联选择框 -->
            <!--
              v-model: 双向绑定选中的数值数组
              options: 指定数据源
              props: 配置选项
              selectCateChange: 选中一个级别时触发
              clearable: 是否可清空
            -->
            <el-cascader
            v-model="selectedCateKeys"
            :options="catelist"
            :props="cascaderProps"
            @change="selectCateChange"
            style="width: 300px;"
            >
            </el-cascader>
        </el-col>
      </el-row>
      <!-- tab页签区域 -->
    <el-tabs v-model="activeName" @tab-click="handleTabClick">
      <!-- 添加动态参数面板 -->
      <el-tab-pane label="动态参数" name="many">
        <el-button size="mini" type="primary" :disabled="isBtnDisabled" @click="addDialogVisible = true">添加参数</el-button>
        <!-- 动态参数表格 -->
        <el-table :data="manyTableData" border stripe>
          <!-- 展开行 -->
          <el-table-column type="expand">
            <template v-slot="slotProps">
              <el-tag v-for="(item, i) in slotProps.row.attr_vals" :key="i" closable @close="handleTagClose(i, slotProps.row)">{{item}}</el-tag>
              <!-- 输入框 -->
              <el-input
                class="input-new-tag"
                v-if="slotProps.row.inputVisible"
                v-model="slotProps.row.inputValue"
                ref="saveTagInput"
                size="small"
                @keyup.enter="handleInputConfirm(slotProps.row)"
                @blur="handleInputConfirm(slotProps.row)"
              >
              </el-input>
              <!-- 添加新标签按钮 -->
              <!-- 点击按钮将这行的数据传过去 -->
              <el-button v-else class="button-new-tag" size="small" @click="showInput(slotProps.row)">+ New Tag</el-button>
            </template>
          </el-table-column>
          <!-- 索引列 -->
          <el-table-column type="index"></el-table-column>
          <el-table-column label="参数名称" prop="attr_name"></el-table-column>
          <el-table-column label="操作">
            <template v-slot="slotProps">
              <!-- 修改按钮 -->
              <el-button type="primary" icon="el-icon-edit" size="mini" @click="showEditDialog(slotProps.row.attr_id)"></el-button>
              <!-- 删除按钮 -->
              <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeById(slotProps.row.attr_id)"></el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <!-- 添加静态属性面板 -->
      <el-tab-pane label="静态属性" name="only">
        <el-button size="mini" type="primary" :disabled="isBtnDisabled" @click="addDialogVisible = true">添加属性</el-button>
        <!-- 静态属性表格 -->
        <el-table :data="onlyTableData" border stripe>
          <!-- 展开行 -->
          <el-table-column type="expand">
            <template v-slot="slotProps">
              <el-tag v-for="(item, i) in slotProps.row.attr_vals" :key="i" closable @close="handleTagClose(i, slotProps.row)">{{item}}</el-tag>
              <!-- 输入框 -->
              <el-input
                class="input-new-tag"
                v-if="slotProps.row.inputVisible"
                v-model="slotProps.row.inputValue"
                ref="saveTagInput"
                size="small"
                @keyup.enter="handleInputConfirm(slotProps.row)"
                @blur="handleInputConfirm(slotProps.row)"
              >
              </el-input>
              <!-- 添加新标签按钮 -->
              <!-- 点击按钮将这行的数据传过去 -->
              <el-button v-else class="button-new-tag" size="small" @click="showInput(slotProps.row)">+ New Tag</el-button>
            </template>
          </el-table-column>
          <!-- 索引列 -->
          <el-table-column type="index"></el-table-column>
          <el-table-column label="属性名称" prop="attr_name"></el-table-column>
          <el-table-column label="操作">
            <template v-slot="slotProps">
              <!-- 修改按钮 -->
              <el-button type="primary" icon="el-icon-edit" size="mini" @click="showEditDialog(slotProps.row.attr_id)"></el-button>
              <!-- 删除按钮 -->
              <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeById(slotProps.row.attr_id)"></el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
    </el-tabs>
    </el-card>
    <!-- 修改/修改参数的对话框 -->
    <!-- 因为title是动态的,所以要使用:title进行动态绑定 -->
    <el-dialog :title="'添加' + titleText" v-model="addDialogVisible" width="50%" @close="addDialogClosed">
      <!-- 内容主体区域表单 -->
      <el-form :model="addForm" :rules="addFormRules" ref="addFormRef" label-width="100px">
        <el-form-item :label="titleText" prop="attr_name">
          <el-input v-model="addForm.attr_name"></el-input>
        </el-form-item>
      </el-form>
      <!-- 底部区域 -->
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="addDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="addDialogClicked">确 定</el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 修改参数对话框 -->
    <el-dialog :title="'修改' + titleText" v-model="editDialogVisible" width="50%" @close="editDialogClosed">
      <!-- 内容主体区域表单 -->
      <el-form :model="editForm" :rules="editFormRules" ref="editFormRef" label-width="100px">
        <el-form-item :label="titleText" prop="attr_name">
          <el-input v-model="editForm.attr_name"></el-input>
        </el-form-item>
      </el-form>
      <!-- 底部区域 -->
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="editDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="editDialogClicked">确 定</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 所有分类数组
      catelist: [],
      // cascader的配置选项
      // expandTrigger: 设置级联选择器的触发方式 hover悬浮触发
      // value: 'cat_id', 选中的是什么值
      // label: 'cat_name', 显示的是什么值
      // children: 'children' 父子嵌套用什么字段
      cascaderProps: {
        expandTrigger: 'hover',
        value: 'cat_id',
        label: 'cat_name',
        children: 'children'
      },
      // 选中的分类的id数组
      selectedCateKeys: [],
      // 选中的tab名称
      activeName: 'many',
      // 动态参数的数据
      manyTableData: [],
      // 静态属性的数据
      onlyTableData: [],
      // 控制添加对话框的显示和隐藏
      addDialogVisible: false,
      // 添加参数的表单数据对象
      addForm: {
        attr_name: '' // 属性名称
      },
      // 添加分类表单的验证规则对象
      addFormRules: {
        attr_name: [
          { required: true, message: '请输入参数名称', trigger: 'blur' },
          { min: 1, max: 10, message: '参数名称的长度在1-10个字符之间', trigger: 'blur' }
        ]
      },
      // 控制修改对话框的显示和隐藏
      editDialogVisible: false,
      // 修改参数的表单数据对象
      editForm: {
        attr_name: '' // 属性名称
      },
      // 添加分类表单的验证规则对象
      editFormRules: {
        attr_name: [
          { required: true, message: '请输入参数名称', trigger: 'blur' },
          { min: 1, max: 10, message: '参数名称的长度在1-10个字符之间', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.getCateList()
  },
  methods: {
    // 获取所有的商品分类数据
    async getCateList() {
      const { data: res } = await this.$http.get('categories')
      if (res.meta.status !== 200) {
        return this.$message.erroe('获取所有分类数据失败')
      }
      this.catelist = res.data
      // console.log(this.catelist)
    },
    // 选中一个级联的时候触发
    selectCateChange() {
      // console.log(this.selectedCateKeys)
      this.getParamsData()
    },
    // 点击tab触发
    handleTabClick() {
      // console.log(this.activeName)
      this.getParamsData()
    },
    // 获取参数的列表数据
    async getParamsData() {
      // 控制只能选择三级分类
      if (this.selectedCateKeys.length !== 3) {
        this.selectedCateKeys = []
        this.manyTableData = []
        this.onlyTableData = []
        return null
      }
      // 根据所选分类的id和对应的面板,获取数据
      const { data: res } = await this.$http.get(`categories/${this.cateId}/attributes`, {
        params: { sel: this.activeName }
      })
      if (res.meta.status !== 200) {
        return this.$message.error('获取对应面板数据失败')
      }
      // console.log(res.data)
      // 将tag标签转换成数组
      res.data.forEach(item => {
        // 服务器返回的attr_vals是字符串:"黄春雨10片-补水滋润,黑春雨10片-轻透补水,白春雨10片-焕白保湿"
        // 不为空就分割,为空就直接返回空数组  将字符串使用,分割放到数组中
        item.attr_vals = item.attr_vals ? item.attr_vals.split(',') : []
        // 为每一行的数据添加inputVisible和inputValue,如果直接把这俩值写到data中,那么所有行都会共用这两个值,这是不对的
        // 控制输入框的显示和隐藏
        item.inputVisible = false
        // 文本框输入的值
        item.inputValue = ''
      })
      // console.log(res.data)
      if (this.activeName === 'many') {
        this.manyTableData = res.data
      } else {
        this.onlyTableData = res.data
      }
    },
    // 添加参数对话框关闭
    addDialogClosed() {
      this.$refs.addFormRef.resetFields()
    },
    // 添加参数对话框-点击确定
    addDialogClicked() {
      this.$refs.addFormRef.validate(async valid => {
        if (!valid) return
        const { data: res } = await this.$http.post(`categories/${this.cateId}/attributes`, {
          attr_name: this.addForm.attr_name,
          attr_sel: this.activeName
        })
        // console.log(res)
        if (res.meta.status !== 201) {
          return this.$message.error('添加参数失败')
        }
        this.$message.success('添加参数成功')
        this.addDialogVisible = false
        this.getParamsData()
      })
    },
    // 显示修改对话框
    async showEditDialog(attrId) {
      const { data: res } = await this.$http.get(`categories/${this.cateId}/attributes/${attrId}`, {
        params: { attr_sel: this.activeName }
      })
      if (res.meta.status !== 200) {
        return this.$message.error('获取参数信息失败')
      }
      this.editForm = res.data
      this.editDialogVisible = true
    },
    // 修改参数对话框关闭
    editDialogClosed() {
      this.$refs.editFormRef.resetFields()
    },
    // 修改参数-点击确定
    editDialogClicked() {
      this.$refs.editFormRef.validate(async valid => {
        if (!valid) return
        console.log(this.editForm)
        console.log(this.activeName)
        console.log(this.cateId)
        const { data: res } = await this.$http.put(`categories/${this.cateId}/attributes${this.editForm.attr_id}`, {
          attr_name: this.editForm.attr_name,
          attr_sel: this.activeName
        })
        console.log(res)
        if (res.meta.status !== 200) {
          return this.$message.error('参数修改失败')
        }
        this.$message.success('参数修改成功')
        this.getParamsData()
        this.editDialogVisible = false
      })
    },
    // 点击删除
    async removeById(attrId) {
      // 需要挂载ElMessageBox.confirm才可以这样使用
      const confirmResult = await this.$confirm('此操作将永久删除参数信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).catch(err => err)
      // 如果删除成功,则返回字符串confirm,如果取消了,则一定要捕获错误,然后取消之后返回字符串cancel
      // console.log(confirmResult)
      if (confirmResult !== 'confirm') {
        return this.$message.info('已经取消了删除')
      }
      const { data: res } = await this.$http.delete(`categories/${this.cateId}/attributes/${attrId}`)
      if (res.meta.status !== 200) {
        return this.$message.error('删除分类失败')
      }
      this.$message.success('删除参数信息成功')
      this.getParamsData()
    },
    // 文本框失去焦点或者按钮enter键都会触发
    handleInputConfirm(row) {
      // 输入值合法性校验
      if (row.inputValue.trim().length === 0) {
        row.inputValue = ''
        row.inputVisible = false
        return null
      }
      // 如果没有return,证明输入的内容合法
      // 先改变UI
      row.attr_vals.push(row.inputValue.trim())
      row.inputValue = ''
      row.inputVisible = false
      // 再发起请求.将tag标签的值传到服务端
      this.saveAttrVals(row)
    },
    // 显示输入框
    showInput(row) {
      // 显示输入框
      row.inputVisible = true
      // $nextTick当页面上元素被重新渲染之后才会执行这个函数的代码,就是等文本输入框被渲染之后才让它获取焦点
      this.$nextTick(_ => {
        // 输入框获取焦点
        this.$refs.saveTagInput.$refs.input.focus()
      })
    },
    // 点解tag标签的x触发
    handleTagClose(i, row) {
      // splice会修改原数组 从i开始删除 删除1位
      row.attr_vals.splice(i, 1)
      // 发起请求
      this.saveAttrVals(row)
    },
    async saveAttrVals(row) {
      // 发起请求.将tag标签的值传到服务端
      const { data: res } = await this.$http.put(`categories/${this.cateId}/attributes/${row.attr_id}`, {
        attr_name: row.attr_name,
        attr_sel: row.attr_sel,
        // 服务端需要字符串,使用,将数组中的数据拼接成字符串传给服务器
        attr_vals: row.attr_vals.join(',')
      })
      if (res.meta.status !== 200) {
        return this.$message.error('更新参数失败')
      }
      this.$message.success('更新参数成功')
    }
  },
  // 计算属性
  computed: {
    // 返回bool值,控制按钮是否可用
    isBtnDisabled() {
      if (this.selectedCateKeys.length !== 3) {
        return true
      }
      return false
    },
    // 三级分类的id
    cateId() {
      if (this.selectedCateKeys.length === 3) {
        return this.selectedCateKeys[2]
      }
      return null
    },
    // 动态计算标题
    titleText() {
      if (this.activeName === 'many') {
        return '动态参数'
      }
      return '静态属性'
    }
  }
}
</script>

<style lang="less" scoped>
.cat_opt {
  margin: 15px 0;
}

.el-tag {
  margin: 10px;
}

.input-new-tag {
  width: 120px;
}
</style>
