<template>
  <div>
    <!-- 面包屑导航 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
    <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
    <el-breadcrumb-item>订单管理</el-breadcrumb-item>
    <el-breadcrumb-item>订单列表</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 卡片视图区域 -->
    <el-card>
      <!-- 搜索区域 -->
      <el-row>
        <el-col :span="8">
          <el-input
            placeholder="请输入内容"
          >
            <template #append>
              <el-button icon="el-icon-search"></el-button>
            </template>
          </el-input>
        </el-col>
      </el-row>
      <!-- 表格区域 -->
      <el-table :data="orderlist" border stripe>
        <el-table-column type="index"></el-table-column>
        <el-table-column label="订单编号" prop="order_number"></el-table-column>
        <el-table-column label="订单价格" prop="order_price"></el-table-column>
        <el-table-column label="是否付款" prop="pay_status">
          <template v-slot="slotProps">
            <el-tag v-if="slotProps.row.pay_status === '1'" type="success">已付款</el-tag>
            <el-tag v-else type="danger">未付款</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="是否发货" prop="is_send"></el-table-column>
        <el-table-column label="下单时间">
            <template v-slot="slotProps">
              {{$filters.dateFormat(slotProps.row.create_time)}}
            </template>
        </el-table-column>
        <el-table-column label="操作">
          <template v-slot="slotProps">
            <el-button size="mini" type="primary" icon="el-icon-edit" @click="editOrderClicked(slotProps.row.order_id)"></el-button>
            <el-button size="mini" type="success" icon="el-icon-location" @click="orderProgressClicked(slotProps.row.order_id)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页区域 -->
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="queryInfo.pagenum"
        :page-sizes="[5, 10, 20, 50]"
        :page-size="queryInfo.pagesize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        background>
      </el-pagination>
    </el-card>
    <!-- 点击修改的对话框 -->
    <el-dialog
      title="修改地址"
      v-model="addressVisible"
      width="50%"
      @close="addressDialogClosed"
      >
      <el-form :model="addAddressForm" :rules="addAddressFormRules" ref="addAddressFormRef" label-width="100px">
        <!-- 通过prop="username"指定具体的校验规则 -->
        <el-form-item label="省市区/县" prop="address1" label-width="100px">
          <!-- style="width: 100%;"只能用stype设置宽度,用类名设置没效果,不知道为什么 -->
          <!-- options数据源  v-model选择之后的结果的双向绑定数组 :props="cascaderProps"配置选项 -->
          <el-cascader :options="cityData"
            v-model="addAddressForm.address1"
            :props="cascaderProps"
            style="width: 100%;"
          >
          </el-cascader>
        </el-form-item>
        <el-form-item label="详细地址" prop="address2" label-width="100px">
          <el-input v-model="addAddressForm.address2"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="addressVisible = false">取 消</el-button>
          <el-button type="primary" @click="addressVisible = false">确 定</el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 展示物流进度的对话框 -->
    <el-dialog
      title="物流进度"
      v-model="progressVisible"
      width="50%"
      @close="progressDialogClosed"
      >
      <el-timeline>
        <el-timeline-item
          v-for="(activity, index) in progressInfos"
          :key="index"
          :timestamp="activity.time">
          {{activity.context}}
        </el-timeline-item>
      </el-timeline>
    </el-dialog>
  </div>
</template>

<script>
// 导入城市数据
import cityData from './citydata.js'
// 导入物流数据假数据
import progressData from './progressData.js'

export default {
  data() {
    return {
      queryInfo: {
        query: '',
        pagenum: 1,
        pagesize: 10
      },
      orderlist: [],
      total: 0,
      addressVisible: false,
      addAddressForm: {
        address1: [],
        address2: ''
      },
      addAddressFormRules: {
        address1: [
          { required: true, message: '请选选择省市区/县', triger: 'blur' }
        ],
        address2: [
          { required: true, message: '请输入详细地址', triger: 'blur' }
        ]
      },
      // 城市数据
      cityData,
      // cascader的配置选项
      // expandTrigger: 设置级联选择器的触发方式 hover悬浮触发
      // value: 'cat_id', 选中的是什么值
      // label: 'cat_name', 显示的是什么值
      // children: 'children' 父子嵌套用什么字段
      cascaderProps: {
        expandTrigger: 'hover',
        value: 'value',
        label: 'label',
        children: 'children'
      },
      // 展示物流信息对话框的显示和隐藏
      progressVisible: false,
      // 物流信息
      progressInfos: []
    }
  },
  created() {
    this.getOrderList()
  },
  methods: {
    async getOrderList() {
      const { data: res } = await this.$http.get('orders', {
        params: this.queryInfo
      })
      if (res.meta.status !== 200) {
        return this.$message.error('获取订单列表')
      }
      this.orderlist = res.data.goods
      this.total = res.data.total
      // console.log(this.orderlist)
    },
    // 点击编辑
    editOrderClicked(id) {
      // console.log(id)
      this.addressVisible = true
    },
    // 点击定位,查看订单进度
    async orderProgressClicked(id) {
      // 物流信息获取失败,这里使用假数据
      // const { data: res } = await this.$http.get('/kuaidi/804909574412544580')
      // if (res.meta.status !== 200) {
      //   return this.$message.error('物流信息获取失败')
      // }
      // this.progressInfos = res.data

      // 使用物流数据假数据
      this.progressInfos = progressData.data
      // console.log(this.progressInfo)
      this.progressVisible = true
    },
    // 监听分页size改变的事件
    handleSizeChange(newSize) {
      this.queryInfo.pagesize = newSize
      // 重新请求数据
      this.getOrderList()
    },
    // 监听页码值改变
    handleCurrentChange(newPage) {
      this.queryInfo.pagenum = newPage
      // 重新请求数据
      this.getOrderList()
    },
    // 编辑地址对话框关闭
    addressDialogClosed() {
      this.$refs.addAddressFormRef.resetFields()
    }
  }
}
</script>

<style lang="less" scoped>
</style>
