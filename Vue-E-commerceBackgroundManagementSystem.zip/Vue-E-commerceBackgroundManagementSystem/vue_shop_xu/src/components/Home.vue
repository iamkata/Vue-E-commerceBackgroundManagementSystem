<template>
<!-- 总区域 -->
  <el-container class="home-container">
    <!-- 头部区域 -->
    <el-header>
      <div>
        <img src="../assets/heima.png" alt="">
        <span>电商后台管理系统</span>
      </div>
      <el-button type="info" @click="logout">退出</el-button>
    </el-header>
    <el-container>
      <!-- 侧边栏 -->
      <el-aside :width="isCollapse ? '64px' : '200px'">
        <div class="toggle-button" @click="toggleCollapse">|||</div>
        <!-- 侧边栏菜单区域 -->
        <!-- 对于数值和布尔值，如果加上冒号就是v-bind绑定，会保留原来的类型（数值或者布尔值），如果不加冒号就是字符串 -->
        <!-- 所以下面可以写成:unique-opened="true",也可以简写成unique-opened -->
        <!-- 如果写成unique-opened="aaa",因为不是属性绑定,那么就是字符串"aaa",字符串的bool值也是真,所以这样写也生效,但是是错误的 -->
        <!-- :collapse-transition="false"关闭折叠动画 -->
        <!-- router开启路由模式 -->
        <!-- :default-active="activePath"被激活的地址 -->
        <el-menu background-color="#333744"
          text-color="#fff"
          active-text-color="#409EFF" unique-opened :collapse="isCollapse" :collapse-transition="false" router :default-active="activePath">
          <!-- 一级菜单 -->
          <!-- 绑定唯一的index,是字符串,index留着展开和折叠使用 -->
          <el-submenu :index="item.path + ''" v-for="item in menulist" :key="item.id">
            <!-- 一级菜单模板区域 -->
            <template #title>
              <!-- 一级图标 -->
              <i :class="iconsObj[item.id]"></i>
              <!-- 一级文本 -->
              <span>{{item.authName}}</span>
            </template>
            <!-- 二级菜单 -->
            <!-- 如果开启了路由模式,index可以当做跳转的地址 -->
            <el-menu-item :index="'/' + subItem.path" v-for="subItem in item.children" :key="subItem.id" @click="saveNavState('/' + subItem.path)">
              <!-- 二级菜单模板区域 -->
              <template #title>
                <!-- 二级图标 -->
                <i class="el-icon-menu"></i>
                <!-- 二级文本 -->
                <span>{{subItem.authName}}</span>
              </template>
            </el-menu-item>
          </el-submenu>
        </el-menu>
      </el-aside>
      <!-- 正文区域 -->
      <el-main>
        <!-- 路由占位符 -->
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
export default {
  data() {
    return {
      menulist: [],
      // 因为我们在main.js里面导入了字体图标和全局样式表了,所以在这里可以直接使用
      iconsObj: {
        125: 'iconfont icon-user',
        103: 'iconfont icon-tijikongjian',
        101: 'iconfont icon-shangpin',
        102: 'iconfont icon-danju',
        145: 'iconfont icon-baobiao'
      },
      // 是否折叠
      isCollapse: false,
      // 被激活的链接地址
      activePath: ''
    }
  },
  // 在实例创建完成后被立即调用，此时data 和 methods已经可以使用，但是页面还没有渲染出来
  created() {
    this.getMenuList()
    this.activePath = window.sessionStorage.getItem('activePath')
  },
  methods: {
    logout () {
      window.sessionStorage.clear()
      this.$router.push('/login')
      this.$message.sucess('退出登录成功')
    },
    // 获取所有的菜单
    async getMenuList() {
      const { data: res } = await this.$http.get('menus')
      if (res.meta.status !== 200) return this.$message.error(res.meta.msg)
      this.menulist = res.data
      // console.log(res.data)
    },
    // 点击按钮,折叠和展开
    toggleCollapse() {
      this.isCollapse = !this.isCollapse
    },
    // 点击二级菜单,保存点击的地址值,然后在组件被创建的时候再取出来
    saveNavState(activePath) {
      window.sessionStorage.setItem('activePath', activePath)
      this.activePath = activePath
    }
  }
}
</script>

<style lang="less" scoped>
// element-ui里面元素的名字同时也是类名,所以可以使用.
.el-header {
  background-color: #373d41;
  display: flex;
  // 左右贴边对齐
  justify-content: space-between;
  padding-left: 0;
  // 设置侧轴上的子元素排列方式（单行）
  align-items: center;
  color: #fff;
  font-size: 20px;
  > div { //亲儿子选择器
    display: flex;
    align-items: center;
    span {
      margin-left: 15px;
    }
  }
}

.el-aside {
  background-color: #333744;
  .el-menu {
    border-right: none;
  }
}

.el-main {
  background-color: #EAEDF1;
}

.home-container {
  height: 100%;
}

.iconfont {
  margin-right: 10px;
}

.toggle-button {
  background-color: #4A5064;
  font-size: 10px;
  line-height: 24px;
  color: #fff;
  text-align: center;
  letter-spacing: 0.5em;
  cursor: pointer;
}

</style>
