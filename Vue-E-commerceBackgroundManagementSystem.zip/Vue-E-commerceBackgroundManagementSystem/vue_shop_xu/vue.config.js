// vue.config.js
// 这个文件中，应该导出一个包含了自定义配置选项的对象
module.exports = {
  // 选项...
  chainWebpack: config => {
    // 使用config接收默认的webpack配置对象

    // 发布模式
    config.when(process.env.NODE_ENV === 'production', config => {
      // config.entry('app').clear() 获取到默认的打包入口，并清空
      // add('./src/main-prod.js') 添加新的打包入口
      config.entry('app').clear().add('./src/main-prod.js')

      // 通过config.plugin找到html插件,通过tap方法给第一个元素添加isProd属性
      config.plugin('html').tap(args => {
        args[0].isProd = true
        return args
      })

      // 发布模式配置externals
      config.set('externals', {
        // 如果有import导入vue-router，就不会合并这个包，会去全局对象window身上找VueRouter来使用
        vue: 'Vue', 'vue-router': 'VueRouter',
        axios: 'axios',
        lodash: '_',
        echarts: 'echarts',
        nprogress: 'NProgress', 'vue-quill-editor': 'VueQuillEditor'
      })
    })
    // 开发模式
    config.when(process.env.NODE_ENV === 'development', config => {
      config.entry('app').clear().add('./src/main-dev.js')

      config.plugin('html').tap(args => {
        args[0].isProd = false
        return args
      })
    })
  } 
}