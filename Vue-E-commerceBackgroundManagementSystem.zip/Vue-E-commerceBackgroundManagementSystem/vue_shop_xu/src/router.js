import { createRouter, createWebHashHistory } from 'vue-router'
// import Login from './components/Login.vue'
// import Home from './components/Home.vue'
// import Welcome from './components/Welcome.vue'
// import Users from './components/user/Users.vue'
// import Rights from './components/power/Rights.vue'
// import Roles from './components/power/Roles.vue'
// import Cate from './components/goods/Cate.vue'
// import Params from './components/goods/Params.vue'
// import List from './components/goods/List.vue'
// import Add from './components/goods/Add.vue'
// import Order from './components/order/Order.vue'
// import Report from './components/report/Report.vue'

// 将上面所有路由导入的方式转成路由懒加载的形式

// 前面的注释语法是分组，后面的是组件的路径，同一组的组件会被打包到同一个js文件中
// 当加载一组中的某个组件的时候会顺便把分组中的其他组件给加载了
const Login = () => import(/* webpackChunkName: "Login_Home_Welcome" */ './components/Login.vue')
const Home = () => import(/* webpackChunkName: "Login_Home_Welcome" */ './components/Home.vue')
const Welcome = () => import(/* webpackChunkName: "Login_Home_Welcome" */ './components/Welcome.vue')

const Users = () => import(/* webpackChunkName: "Users_Rights_Roles" */ './components/user/Users.vue')
const Rights = () => import(/* webpackChunkName: "Users_Rights_Roles" */ './components/power/Rights.vue')
const Roles = () => import(/* webpackChunkName: "Users_Rights_Roles" */ './components/power/Roles.vue')

const Cate = () => import(/* webpackChunkName: "Cate_Params" */ './components/goods/Cate.vue')
const Params = () => import(/* webpackChunkName: "Cate_Params" */ './components/goods/Params.vue')

const List = () => import(/* webpackChunkName: "List_Add" */ './components/goods/List.vue')
const Add = () => import(/* webpackChunkName: "List_Add" */ './components/goods/Add.vue')

const Order = () => import(/* webpackChunkName: "Order_Report" */ './components/order/Order.vue')
const Report = () => import(/* webpackChunkName: "Order_Report" */ './components/report/Report.vue')

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: Login },
  {
    // 登录之后进入'/home','/home'又重定向到'/welcome',然后将welcome组件显示到Main区域
    path: '/home',
    component: Home,
    redirect: '/welcome',
    children: [
      // 这些都是home组件的子组件
      // 如果 path: '/users',匹配的是 http://localhost:8080/#/users
      // 如果 path: 'users',匹配的是 http://localhost:8080/#/home/users
      { path: '/welcome', component: Welcome },
      { path: '/users', component: Users },
      { path: '/rights', component: Rights },
      { path: '/roles', component: Roles },
      { path: '/categories', component: Cate },
      { path: '/params', component: Params },
      { path: '/goods', component: List },
      { path: '/goods/add', component: Add },
      { path: '/orders', component: Order },
      { path: '/reports', component: Report }
    ]
  }
]

const router = createRouter({
  // 使用 hash 路由
  history: createWebHashHistory(),
  routes
})

// 注册一个全局前置守卫
// to:到哪里去 from:从哪里来 next():放行  next('/login'):强制跳转
router.beforeEach((to, from, next) => {
  if (to.path === '/login') return next()
  const tokenStr = window.sessionStorage.getItem('token')
  if (!tokenStr) return next('/login')
  next()
})

// 将路由导出
export default router
